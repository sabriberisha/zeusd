#!/bin/sh

# This is just a short script file you can use to test if the hosts
# file on SecureMecca.com and HostsFile.org has been changed.

echo
if [ ! -d OldDate ]
then
	mkdir OldDate
	cd OldDate
	wget -q www.securemecca.com/Downloads/hdate.txt
	echo priming the pump since you do not have an old date file
	echo
	cd ..
	exit 0
fi
if [ ! -f OldDate/hdate.txt ]
then
	cd OldDate
	wget -q www.securemecca.com/Downloads/hdate.txt
	echo priming the pump since you do not have an old date file
	echo
	cd ..
	exit 0
fi

# You are encouraged to replace the editor with the the one of your
# choice.  For Airelle that is psPad.  For Rodney - alias DomainAnalysis
# I think it is NotePad++.  For me it is GVim.  Pick your own poison.
rm -f hdate.txt
wget -q www.securemecca.com/Downloads/hdate.txt
if [ -f hdate.txt ]
then
	if diff OldDate/hdate.txt hdate.txt
	then
		echo The hosts file at SecureMecca.com and HostsFile.org has NOT changed.
		rm -f hdate.txt
	else
		cp -fp hdate.txt OldDate/hdate.txt
		echo THE HOSTS FILE AT SecureMecca.com AND HostsFile.org HAS CHANGED.
		LINES=`wc -l hdate.txt | gawk '{print $1}'`
		case $LINES in
		0 | 1)
			rm -f hdate.txt
			;;
		*)
			gedit hdate.txt &
			;;
		esac
	fi
else
	echo WE FAILED TO PULL DOWN THE hdate.txt FILE SO STATUS IS UNKNOWN
fi
echo

exit

