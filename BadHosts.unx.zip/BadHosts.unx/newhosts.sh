#!/bin/sh

# This only supports Fedora Core 3.  It is hoped that it can be
# expanded to support as many versions of Unix, Linux, and BSD
# as possible.

fedoraorredhat() {

	cp -p /tmp/hosts.lnx /etc/hosts.lnx
	chmod 644 /etc/hosts.lnx
	chown 0:0 /etc/hosts.lnx

	# next lines ONLY for Fedora Core 3
	rm -f /etc/sysconfig/networking/profiles/default/hosts
	rm -f /etc/hosts

	cat /etc/hosts.org /etc/hosts.lnx > /etc/hosts
	chmod 644 /etc/hosts
	chown 0:0 /etc/hosts

	# next three lines ONLY for Fedora Core 3
	ln /etc/hosts /etc/sysconfig/networking/profiles/default/hosts
	chmod 644 /etc/sysconfig/networking/profiles/default/hosts
	chown 0:0 /etc/sysconfig/networking/profiles/default/hosts

	exit
}

#
# Do some initial checks to make sure we can install
#

WHOAMI=`whoami`
if [ "$WHOAMI" != "root" ]
then
	echo
	echo you must be root to add the hosts file entries
	echo
	exit 1
fi

# The following will give you host additions sans localhost.
# Note that if localhosts.3322.org goes away that line will
# be removed.

rm -f /tmp/hosts.lnx
grep -v localhost hosts.lnx > /tmp/hosts.lnx
grep localhosts.3322.org hosts.lnx >> /tmp/hosts.lnx

if [ ! -f /tmp/hosts.lnx ] || [ ! -f /etc/hosts.org ]
then
	echo you need to backup your original hosts file
	echo to /tmp/hosts.org
	exit 1
fi

#
#  Select OS to install - so far only Fedora Core 3 and maybe
#  RHEL are supported.
#

OPERATINGSYSTEM=`uname -o`

case $OPERATINGSYSTEM in
GNU/Linux)
	if [ -x /sbin/chkconfig ] && [ -d /etc/rc.d/init.d ] && [ -d /etc/rc.d/rc5.d ]
	then
		# Fedora Core 3 test
		if [ -f /etc/sysconfig/networking/profiles/default/hosts ] && [ -f /etc/hosts ]
		then
			fedoraorredhat
		fi
	fi
	echo unsupported version of Linux
	;;
*)
	echo unsupported version of Unix
	;;
esac

exit

