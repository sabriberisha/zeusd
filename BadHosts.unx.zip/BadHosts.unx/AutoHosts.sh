#!/bin/sh
#
#  AutoHosts.sh
#  Author :   Henry Hertz Hobbit
#  Version :  2.0.0
#
# http://www.gnu.org/licenses/lgpl.txt
#
#  All this script does right now is attempt to pull down the hosts
#  files and verify them.  There are so many variations I don't know
#  what to do.  Does the person have a GnuPG key?  Did they import my
#  OpenPGP key?  Believe it or not some people will never have a GnuPG
#  key.  Do they have sha1sum?  Do they have md5sum? As hard as that
#  is to believe some old mossbacks using Sun Solaris or AIX may not
#  have EITHER of them.  In reality we need a check sum better than both
#  MD5 and SHA1 now.  Have they installed 7zip?  We haven't even got to
#  whether they are just going to use PERL to massage the data for their
#  squid proxy, merging this data with data from other sources or
#  whether they are going to actually make a blocking hosts file.
#
#  I do have one thing to say though.  FOR HEAVEN'S SAKE INSTALL
#  7-ZIP IF YOU CAN.  The binary install packages are even available
#  for Linux and Mac OS-X now.  Not only that but I LOVE the fact that
#  you can throw the UID:GID out the door for an install file.  They are
#  also only 1/2 to 2/3 the size of ZIP files and also beat both GZIP
#  and BZIP2.  But if you don't have 7-Zip I am providing them in ZIP
#  format.  I don't know how long that is going to last.  In other
#  words, get 7-Zip.
#

CURDIR=`pwd`

cd /tmp

# no hdate.txt file then make one that WILL be different
if [ ! -d OldDate ]
then
	mkdir OldDate
fi
if [ ! -f OldDate/hdate.txt ]
then
	ls -l > OldDate/hdate.txt
fi

wget www.securemecca.com/Downloads/hdate.txt
if [ -f OldDate/hdate.txt ] && [ -f hdate.txt ]
then
	if  diff OldDate/hdate.txt hdate.txt
	then
		echo
		echo The hosts file at SecureMecca.com has NOT changed
		echo
		touch OldDate/hdate.txt OldDate
		rm -f hdate.txt
		exit 0
	fi
fi

rm -fr AutoHosts.unx*

if 7za --help > /dev/null
then
	wget www.securemecca.com/Downloads/AutoHosts.unx.7z
	if [ -f AutoHosts.unx.7z ]
	then
		7za x AutoHosts.unx.7z
	else
		echo
		echo failed to get AutoHosts.unx.7z so exiting
		echo
		exit 1
	fi
else
	wget www.securemecca.com/Downloads/AutoHosts.unx.zip
	if [ -f AutoHosts.unx.zip ]
	then
		unzip AutoHosts.unx.zip
	else
		echo
		echo failed to get AutoHosts.unx.zip so exiting
		echo
		exit 1
	fi
fi

if [ -d AutoHosts.unx ]
then
	cd AutoHosts.unx
	if sha1sum --version > /dev/null 2>&1
	then
		if sha1sum -c sums.sha1
		then
			echo The SHA1 check sums are OKAY
		else
			echo The SHA1 check sums FAILED.
		fi
	else
		if md5sum --version > /dev/null 2>&1
		then
			if md5sum -c sums.md5
			then
				echo The MD5 check sums are OKAY
			else
				echo The MD5 check sums FAILED.
			fi
		else
			echo You appear to have neither MD5 or SHA1 checksum
			echo programs. Therefore you have what you have.
			echo You will have to do the rest manually.
		fi
	fi
	if [ -f AutoHosts.sh ]
	then
		if [ -f ${CURDIR}/AutoHosts.sh ]
		then
			if ! diff ${CURDIR}/AutoHosts.sh AutoHosts.sh
			then
				echo new AutoHosts.sh file in download is different
			fi
		else
			echo new AutoHosts.sh file in download
		fi
	fi
else
	echo
	echo failed to unzip the AutoHosts.unx directory
	echo
fi

exit

